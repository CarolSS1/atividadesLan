public class exemplo2 {
    public static void main(String[] args) {
        
        char option;
        option = 'c';
        int x = 42;
        double f = -42.5342;

        System.out.println("Alô mundoo!!");    
    }
}
