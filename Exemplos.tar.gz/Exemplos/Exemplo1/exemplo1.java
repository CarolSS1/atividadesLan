public class exemplo1 {
// Comentarios de uma linha 
/* Comentario de várias linhas
*/
/** Comentário de documentação */
    public static void main(String[] args) {
        System.out.println("Alô mundo!!");
    } 
}
