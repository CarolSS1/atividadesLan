package com.example.alunos.exemploactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.Random;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    int c = 3;
    Random gerador = new Random();
    int num_aleatorio = gerador.nextInt(11);
    public void mudaTexto(View v){
        TextView mensagem = (TextView) findViewById(R.id.id);
        EditText cxeNum = findViewById(R.id.cxeNum);
        String usuario = cxeNum.getText().toString();

        int num;
        String msg;
        num = Integer.parseInt(usuario);
            if(num == num_aleatorio){
                 msg = "Parabéns! Você acertou!";
                mensagem.setText(msg);
                c = 0;
            } else {
                --c;
                if(c == 0){
                    msg = "Você perdeu! O número era " + num_aleatorio;
                    mensagem.setText(msg);
                } else {
                    msg = "Você errou! Ainda tem " + c + " chance(s)";
                    mensagem.setText(msg);
                }

            }
    }
}
